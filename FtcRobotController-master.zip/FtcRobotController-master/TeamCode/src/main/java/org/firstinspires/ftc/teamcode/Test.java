package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
/*
import com.qualcomm.robotcore.hardware.Servo;
*/

@TeleOp(name="Test")

public class Test extends OpMode {

    DcMotor motor1;
    DcMotor motor2;
    DcMotor motor3;
    DcMotor motor4;
    DcMotor motorI;
    DcMotor motorII;
    DcMotor motorIII;


    @Override
    public void init() {

        motor1 = hardwareMap.get(DcMotor.class, "motor1"); //fata stanga
        motor1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    telemetry.addData("Motor1", "init & NoEnc");

        motor2 = hardwareMap.get(DcMotor.class, "motor2"); //spate stanga
        motor2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    telemetry.addData("Motor2", "init & NoEnc");

        motor3 = hardwareMap.get(DcMotor.class, "motor3"); //fata dreapta
        motor3.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        motor3.setDirection(DcMotorSimple.Direction.REVERSE);
    telemetry.addData("Motor3", "init & NoEnc & Rev");

        motor4 = hardwareMap.get(DcMotor.class, "motor4"); //spate dreapta
        motor4.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        motor4.setDirection(DcMotorSimple.Direction.REVERSE);
    telemetry.addData("Motor4", "init & NoEnc & Rev");

        motorI = hardwareMap.get(DcMotor.class, "motorI"); //motor I
        motorI.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    telemetry.addData("MotorI", "init & NoEnc");

        motorII = hardwareMap.get(DcMotor.class, "motorII"); //motor II
        motorII.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    telemetry.addData("MotorII", "init & NoEnc");

        motorIII = hardwareMap.get(DcMotor.class, "motorIII"); //motor III
        motorIII.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    telemetry.addData("MotorIII", "init & NoEnc");

        telemetry.update();

    }

    @Override
    public void loop() {
        double x = gamepad1.left_stick_x;
        double y = -gamepad1.left_stick_y;
        double rx = gamepad1.right_stick_x;

        double m = Math.max(1.0, Math.abs(x)+Math.abs(y)+Math.abs(rx));

        motor1.setPower((y+x+rx)/m);
        telemetry.addData("Motor1", (y+x+rx)/m);
        motor2.setPower((y-x+rx)/m);
        telemetry.addData("Motor2", (y-x+rx)/m);
        motor3.setPower((y-x-rx)/m);
        telemetry.addData("Motor3", (y-x-rx)/m);
        motor4.setPower((y+x-rx)/m);
        telemetry.addData("Motor4", (y+x-rx)/m);

        if (gamepad1.a)
        {
            motorI.setPower(0.5);
        }
        if (gamepad1.b){
            motorII.setPower(0.5);
        }
        if (gamepad1.x){
            motorIII.setPower(0.5);
        }
    }
}
